<?php
include '../includes/connect.php';
	foreach ($_POST as $key => $value)
	{
		if(preg_match("/[0-9]+_name/",$key)){
			if($value != ''){
			$key = strtok($key, '_');
			$value = htmlspecialchars($value);
			$sql = "UPDATE items SET name = '$value' WHERE id = $key;";
			$con->query($sql);
			}
		}
		if(preg_match("/[0-9]+_price/",$key)){
			$key = strtok($key, '_');
			$sql = "UPDATE items SET price = $value WHERE id = $key;";
			$con->query($sql);
		}
		if(preg_match("/[0-9]+_amount/",$key)){
			$key = strtok($key, '_');
			$sql = "UPDATE items SET amount = $value WHERE id = $key;";
			$con->query($sql);
		}
		if(preg_match("/[0-9]+_image/",$key)){
			$key = strtok($key, '_');
			$sql = "UPDATE items SET image = $value WHERE id = $key;";
			$con->query($sql);
		}
		}
header("location: ../admin-page.php");
?>