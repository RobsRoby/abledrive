<?php
include '../includes/connect.php';

$name = $_POST['name'];
$price = $_POST['price'];
$amount = $_POST['amount'];
$image = $_POST['image'];
$sql = "INSERT INTO items (name, price, amount, image) VALUES ('$name', '$price', '$amount', '$image')";
$con->query($sql);
header("location: ../admin-page.php");
?>