<html>
<body>
<table border="1">
	<tr>
		<td>PANCIT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; P10<br><img src="logo.jpg"><br><br><br><br>Quantity<input type="number" value="0">
	